package com.example.onseinippou.domain.model.report;

public class Sheet {

}
