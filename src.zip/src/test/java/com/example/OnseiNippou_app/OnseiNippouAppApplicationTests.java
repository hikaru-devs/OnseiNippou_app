package com.example.OnseiNippou_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnseiNippouAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
